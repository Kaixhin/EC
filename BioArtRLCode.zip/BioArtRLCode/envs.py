from collections import deque
import atari_py
import cv2
import gym
from gym import spaces
from matplotlib import pyplot as plt
import numpy as np
import seaborn as sns
import torch


class _GymEnv():
  def __init__(self, args):
    self.device = args.device

  @property
  def action_space(self):
    return self._env.action_space

  @property
  def observation_space(self):
    return self._env.observation_space

  def reset(self):
    obs = self._env.reset()
    obs = obs.astype(np.float32)
    self.state_hash = obs  # Cache current state as state hash
    obs = torch.tensor(obs, dtype=torch.float32, device=self.device)
    return obs

  def step(self, action):
    obs, reward, done, _ = self._env.step(action)
    obs = obs.astype(np.float32)
    self.state_hash = obs
    obs = torch.tensor(obs, dtype=torch.float32, device=self.device)
    return obs, reward, done

  def seed(self, seed):
    return self._env.seed(seed)

  def train(self):
    pass

  def eval(self):
    pass

  def render(self):
    return self._env.render()

  def close(self):
    return self._env.close()

  @property
  def hash_space(self):
    return self._env.observation_space
  
  def get_state_hash(self):
    return self.state_hash

  def load(self, state):
    self.state = state


class AcrobotEnv(_GymEnv):
  def __init__(self, args):
    super().__init__(args)
    self._env = gym.make('Acrobot-v1')


class CartpoleEnv(_GymEnv):
  def __init__(self, args):
    super().__init__(args)
    self._env = gym.make('CartPole-v1')

  def load(self, state):
    super.load(state)
    self.steps_beyond_done = None  # TODO: Technically this would be need to be saved and restored


class MountainCarEnv(_GymEnv):
  def __init__(self, args):
    super().__init__(args)
    self._env = gym.make('MountainCar-v0')


class _RoomEnv():
  def __init__(self, args):
    self.device = args.device
    self.T = 100  # Timeout

  @property
  def action_space(self):
    return spaces.Discrete(4)

  @property
  def observation_space(self):
    return spaces.Box(low=0, high=max(self.size_x, self.size_y), dtype=np.float32, shape=(2, ))

  def reset(self):
    self.agent_x, self.agent_y = 1, 1
    obs = torch.tensor([self.agent_x, self.agent_y], dtype=torch.float32, device=self.device)
    self.t = 0
    return obs

  def step(self, action):
    if action == 0 and (self.agent_x, self.agent_y + 1) not in self._walls:  # N
      self.agent_y += 1
    elif action == 1 and (self.agent_x + 1, self.agent_y) not in self._walls:  # E
      self.agent_x += 1
    elif action == 2 and (self.agent_x, self.agent_y - 1) not in self._walls:  # S
      self.agent_y -= 1
    elif action == 3 and (self.agent_x - 1, self.agent_y) not in self._walls:  # W
      self.agent_x -= 1
    reward = 1 if (self.agent_x == self.goal_x and self.agent_y == self.goal_y) else 0
    self.t += 1
    done = reward == 1 or self.t == self.T
    obs = torch.tensor([self.agent_x, self.agent_y], dtype=torch.float32, device=self.device)
    return obs, reward, done

  def seed(self, seed):
    pass

  def train(self):
    pass

  def eval(self):
    pass

  def render(self):
    screen = np.ones((self.size_y, self.size_x), dtype=np.float32)
    screen[self.walls[0], self.walls[1]] = 0.7
    screen[self.agent_y, self.agent_x] = 0
    screen[self.goal_y, self.goal_x] = 0.3
    cv2.imshow('screen', screen)
    cv2.waitKey(1)

  def close(self):
    cv2.destroyAllWindows()

  @property
  def hash_space(self):
    return spaces.Box(low=0, high=max(self.size_x, self.size_y), dtype=np.float32, shape=(2, ))
  
  def get_state_hash(self):
    return np.array([self.agent_x, self.agent_y], dtype=np.float32)

  def load(self, state):
    self.agent_x, self.agent_y = state[0], state[1]
    self.t = 0   # TODO: Technically this would be need to be saved and restored

  def get_all_valid_states(self):
    return torch.tensor(np.stack(self.walkable, axis=1), dtype=torch.float32, device=self.device)

  # Plots Q-values for each action of each valid state (based on self.walkable)
  def plot_qs(self, qs, path):
    states = np.zeros((5, self.size_y, self.size_x), dtype=np.float32)  # Q-values are in [0, 1] for room environments
    states[0, self.walkable[0], self.walkable[1]] = np.argmax(qs, axis=1)
    states[1:, self.walkable[0], self.walkable[1]] = qs.transpose()
    fig, ax = plt.subplots(1, 5, figsize=(10, 2))
    ax[0].set_axis_off()
    ax[0].imshow(states[0], vmin=0, vmax=3)  # TODO: Annotate action?
    [sns.heatmap(states[i], vmin=0, vmax=1, cbar=None, xticklabels=False, yticklabels=False, ax=ax[i]) for i in range(1, 5)]
    [ax[i].title.set_text(a) for i, a in enumerate(['Policy', 'N', 'E', 'S', 'W'])]
    plt.savefig(path)
    plt.close()


class OpenRoomEnv(_RoomEnv):
  def __init__(self, args):
    super().__init__(args)
    self.size_x, self.size_y = 12, 12
    self.goal_x, self.goal_y = 10, 10
    walls = [[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
             [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
             [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
             [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
             [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
             [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
             [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
             [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
             [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
             [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
             [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
             [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]]
    self.walls, self.walkable = np.nonzero(walls), np.nonzero(np.asarray(walls) - 1)
    self._walls = [(x, y) for y, x in zip(*self.walls)]


class IMazeEnv(_RoomEnv):
  def __init__(self, args):
    super().__init__(args)
    self.size_x, self.size_y = 17, 5
    self.goal_x, self.goal_y = 15, 3
    walls = [[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
             [1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1],
             [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
             [1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1],
             [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]]
    self.walls, self.walkable = np.nonzero(walls), np.nonzero(np.asarray(walls) - 1)
    self._walls = [(x, y) for y, x in zip(*self.walls)]


class FourRoomEnv(_RoomEnv):
  def __init__(self, args):
    super().__init__(args)
    self.size_x, self.size_y = 13, 13
    self.goal_x, self.goal_y = 11, 11
    walls = [[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
             [1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1],
             [1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1],
             [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
             [1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1],
             [1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1],
             [1, 1, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1],
             [1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 1, 1, 1],
             [1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1],
             [1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1],
             [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
             [1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1],
             [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]]
    self.walls, self.walkable = np.nonzero(walls), np.nonzero(np.asarray(walls) - 1)
    self._walls = [(x, y) for y, x in zip(*self.walls)]


class AtariEnv():
  def __init__(self, args):
    self.device = args.device
    self.ale = atari_py.ALEInterface()
    self.ale.setInt('random_seed', args.seed)
    self.ale.setInt('max_num_frames_per_episode', args.max_episode_length)
    self.ale.setFloat('repeat_action_probability', 0)  # Disable sticky actions
    self.ale.setInt('frame_skip', 0)
    self.ale.setBool('color_averaging', False)
    self.ale.loadROM(atari_py.get_game_path(args.game))  # ROM loading must be done after setting options
    actions = self.ale.getMinimalActionSet()
    self.actions = dict([i, e] for i, e in zip(range(len(actions)), actions))
    self.lives = 0  # Life counter (used in DeepMind training)
    self.life_termination = False  # Used to check if resetting only from loss of life
    self.window = args.history_length  # Number of frames to concatenate
    self.state_buffer = deque([], maxlen=args.history_length)
    self.training = True  # Consistent with model training mode

  @property
  def action_space(self):
    return spaces.Discrete(len(self.actions))

  @property
  def observation_space(self):
    return spaces.Box(low=0, high=1, dtype=np.float32, shape=(4, 84, 84))

  def _get_state(self):
    state = cv2.resize(self.ale.getScreenGrayscale(), (84, 84), interpolation=cv2.INTER_LINEAR)
    return torch.tensor(state, dtype=torch.float32, device=self.device).div_(255)

  def _reset_buffer(self):
    for _ in range(self.window):
      self.state_buffer.append(torch.zeros(84, 84, device=self.device))

  def reset(self):
    if self.life_termination:
      self.life_termination = False  # Reset flag
      self.ale.act(0)  # Use a no-op after loss of life
    else:
      # Reset internals
      self._reset_buffer()
      self.ale.reset_game()
      # Perform up to 30 random no-ops before starting
      for _ in range(np.random.randint(30)):
        self.ale.act(0)  # Assumes raw action 0 is always no-op
        if self.ale.game_over():
          self.ale.reset_game()
    # Process and return "initial" state
    observation = self._get_state()
    self.state_buffer.append(observation)
    self.lives = self.ale.lives()
    return torch.stack(list(self.state_buffer), 0)

  def step(self, action):
    # Repeat action 4 times, max pool over last 2 frames
    frame_buffer = torch.zeros(2, 84, 84, device=self.device)
    reward, done = 0, False
    for t in range(4):
      reward += self.ale.act(self.actions.get(action))
      if t == 2:
        frame_buffer[0] = self._get_state()
      elif t == 3:
        frame_buffer[1] = self._get_state()
      done = self.ale.game_over()
      if done:
        break
    observation = frame_buffer.max(0)[0]
    self.state_buffer.append(observation)
    # Detect loss of life as terminal in training mode
    if self.training:
      lives = self.ale.lives()
      if lives < self.lives and lives > 0:  # Lives > 0 for Q*bert
        self.life_termination = not done  # Only set flag when not truly done
        done = True
      self.lives = lives
    # Return state, reward, done
    return torch.stack(list(self.state_buffer), 0), reward, done

  def seed(self, seed):
    pass  # Atari environment can only be seeded at initialisation

  # Uses loss of life as terminal signal
  def train(self):
    self.training = True

  # Uses standard terminal signal
  def eval(self):
    self.training = False

  def render(self):
    cv2.imshow('screen', self.ale.getScreenRGB()[:, :, ::-1])
    cv2.waitKey(1)

  def close(self):
    cv2.destroyAllWindows()

  @property
  def hash_space(self):
    return spaces.Box(low=0, high=1, dtype=np.float32, shape=(128, ))
  
  def get_state_hash(self):
    return self.ale.getRAM().astype(np.float32) / 255

  def load(self, state):
    raise NotImplementedError


def get_env(args):
  if args.env == 'cartpole':
    env = CartpoleEnv
  elif args.env == 'acrobot':
    env = AcrobotEnv
  elif args.env == 'mountaincar':
    env = MountainCarEnv
  elif args.env == 'openroom':
    env = OpenRoomEnv
  elif args.env == 'imaze':
    env = IMazeEnv
  elif args.env == 'fourroom':
    env = FourRoomEnv
  elif args.env == 'atari':
    env = AtariEnv
  env = env(args)
  return env
