import GPy
import numpy as np
from scipy.spatial.distance import cdist, pdist


# Looks like inverse multiquadric kernel? http://crsouza.com/2010/03/17/kernel-functions-for-machine-learning-applications/
class InverseDistance(GPy.kern.src.kern.Kern):
  def __init__(self, input_dim, delta=1e-3, active_dims=None):
    super().__init__(input_dim, active_dims, 'inv_dist')
    self.delta = GPy.core.parameterization.param.Param('delta', delta)
    self.link_parameters(self.delta)

  def K(self, X, X2=None):
    X2 = X if X2 is None else X2
    self._cov = 1 / (cdist(X, X2, 'euclidean') + self.delta)  # Cache covariance for further computations
    return self._cov

  def Kdiag(self, X):
    return 1 / self.delta * np.ones(X.shape[0]) 

  def update_gradients_full(self, dL_dK, X, X2=None):
    X2 = X if X2 is None else X2
    dK_ddelta = -1 / (self._cov + self.delta) ** 2  # TODO: Check that X and X2 are same as were used previously
    self.delta.gradient = np.sum(dL_dK * dK_ddelta)

