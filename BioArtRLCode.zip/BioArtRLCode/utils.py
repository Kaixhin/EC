from datetime import datetime
import os
import cv2
import faiss
import numpy as np
import plotly
from plotly.graph_objs import Scatter
from plotly.graph_objs.scatter import Line
import torch
import umap
import pandas as pd 
import seaborn as sns
from matplotlib import pyplot as plt
from sklearn.neighbors import KernelDensity



def knn_search(queries, data, k, return_neighbours=False, res=None):
  num_queries, dim = queries.shape
  if res is None:
    dists, idxs = np.empty((num_queries, k), dtype=np.float32), np.empty((num_queries, k), dtype=np.int64)
    heaps = faiss.float_maxheap_array_t()
    heaps.k, heaps.nh = k, num_queries
    heaps.val, heaps.ids = faiss.swig_ptr(dists), faiss.swig_ptr(idxs)
    faiss.knn_L2sqr(faiss.swig_ptr(queries), faiss.swig_ptr(data), dim, num_queries, data.shape[0], heaps)
  else:
    dists, idxs = torch.empty(num_queries, k, dtype=torch.float32, device=queries.device), torch.empty(num_queries, k, dtype=torch.int64, device=queries.device)
    faiss.bruteForceKnn(res, faiss.METRIC_L2, faiss.cast_integer_to_float_ptr(data.storage().data_ptr() + data.storage_offset() * 4), data.is_contiguous(), data.shape[0], faiss.cast_integer_to_float_ptr(queries.storage().data_ptr() + queries.storage_offset() * 4), queries.is_contiguous(), num_queries, dim, k, faiss.cast_integer_to_float_ptr(dists.storage().data_ptr() + dists.storage_offset() * 4), faiss.cast_integer_to_long_ptr(idxs.storage().data_ptr() + idxs.storage_offset() * 8))
  if return_neighbours:
    neighbours = data[idxs.reshape(-1)].reshape(-1, k, dim)
    return dists, idxs, neighbours
  else:
    return dists, idxs



# Simple ISO 8601 timestamped logger
def log(s):
  print('[' + str(datetime.now().strftime('%Y-%m-%dT%H:%M:%S')) + '] ' + s)


# Plots min, max and mean + standard deviation bars of a population over time
def lineplot(xs, ys_population, title, path='', xaxis='episode'):
  max_colour, mean_colour, std_colour, transparent = 'rgb(0, 132, 180)', 'rgb(0, 172, 237)', 'rgba(29, 202, 255, 0.2)', 'rgba(0, 0, 0, 0)'

  if isinstance(ys_population[0], list) or isinstance(ys_population[0], tuple):
    ys = np.asarray(ys_population, dtype=np.float32)
    ys_min, ys_max, ys_mean, ys_std, ys_median = ys.min(1), ys.max(1), ys.mean(1), ys.std(1), np.median(ys, 1)
    ys_upper, ys_lower = ys_mean + ys_std, ys_mean - ys_std

    trace_max = Scatter(x=xs, y=ys_max, line=Line(color=max_colour, dash='dash'), name='Max')
    trace_upper = Scatter(x=xs, y=ys_upper, line=Line(color=transparent), name='+1 Std. Dev.', showlegend=False)
    trace_mean = Scatter(x=xs, y=ys_mean, fill='tonexty', fillcolor=std_colour, line=Line(color=mean_colour), name='Mean')
    trace_lower = Scatter(x=xs, y=ys_lower, fill='tonexty', fillcolor=std_colour, line=Line(color=transparent), name='-1 Std. Dev.', showlegend=False)
    trace_min = Scatter(x=xs, y=ys_min, line=Line(color=max_colour, dash='dash'), name='Min')
    trace_median = Scatter(x=xs, y=ys_median, line=Line(color=max_colour), name='Median')
    data = [trace_upper, trace_mean, trace_lower, trace_min, trace_max, trace_median]
  else:
    data = [Scatter(x=xs, y=ys_population, line=Line(color=mean_colour))]
  plotly.offline.plot({
    'data': data,
    'layout': dict(title=title, xaxis={'title': xaxis}, yaxis={'title': title})
  }, filename=os.path.join(path, title + '.html'), auto_open=False)


def write_video(frames, title, path=''):
  frames = np.multiply(np.stack(frames, axis=0).transpose(0, 2, 3, 1), 255).astype(np.uint8)[:, :, :, ::-1]  # VideoWrite expects H x W x C in BGR
  _, H, W, _ = frames.shape
  writer = cv2.VideoWriter(os.path.join(path, '%s.mp4' % title), cv2.VideoWriter_fourcc(*'mp4v'), 30., (W, H), True)
  for frame in frames:
    writer.write(frame)
  writer.release()


def plot_embedding(args, class_agent, agent, env, T, results_dir, avg_rew, avg_Q): #Not working on NEC because of the NN
  env_name = args.env if args.symbolic_env else args.game
  path_embeddings = os.path.join(results_dir, 'embeddings')
  os.makedirs(path_embeddings, exist_ok=True)
  xlim, ylim = (-20, 20), (-20, 20) #Defining range for UMAP
  x_val, y_val = np.arange(xlim[0],xlim[1],args.umap_step), np.arange(ylim[0],ylim[1],args.umap_step)
  x_len, y_len = len(x_val), len(y_val)

  embedding = torch.load(os.path.join('embeddings',env_name+'.pth')) #Takes one of the best embedding saved
  keys = np.empty((0,args.key_size),dtype=np.float32)
  keys_index = np.empty((0,1),dtype=np.int32)
  values = np.array([],dtype=np.float32)
  for action in range(agent.action_space): #Extract keys and values to project in the embedding
    indexes = [keys<1e6 for keys in (agent.online_net.memories[action].keys[:,0] if agent.online_net.memories[action].faiss_gpu_resources is None else agent.online_net.memories[action].keys[:,0].cpu().numpy())]
    keys = np.append(keys, agent.online_net.memories[action].keys[indexes] if agent.online_net.memories[action].faiss_gpu_resources is None else agent.online_net.memories[action].keys[indexes].cpu().numpy(),axis=0)
    values = np.append(values, np.squeeze(agent.online_net.memories[action].values[indexes]),axis=0)
    keys_index = np.append(keys_index, int(action)*np.ones((len(values)-len(keys_index),1)),axis=0)
  #Creation of the new 2D Action-State-Space
  StateSpace = pd.DataFrame(data=np.concatenate((embedding.transform(keys), np.reshape(keys_index,(len(keys_index),1)), np.reshape(values,(len(values),1))),axis=1), dtype = np.float32, columns=['x','y','Action','Value'])
  StateSpace = StateSpace.sort_values(by=['Value'])
  #Grid to perform q_evaluation on 'fake' states
  grid_x, grid_y = np.meshgrid(x_val,y_val)
  grid_y = grid_y[::-1,:]
  grid2eval = np.array([[x+args.umap_step/2,y+args.umap_step/2] for x,y in zip(grid_x.reshape((x_len*y_len,1)),grid_y.reshape((x_len*y_len,1)))],dtype=np.float32)
  grid_action = np.array([],dtype=np.int32)
  grid_value = np.array([],dtype=np.float32)
  #Creation of a new 2D agent with the projection of the states
  
  if args.projection is not None: 
    projection = args.projection
    args.projection = None
  else: 
    projection = None
  umap_agent = class_agent(args, env.observation_space.shape, env.action_space.n, env.hash_space.shape[0])
  for action in range(agent.action_space):
    umap_agent.online_net.memories[action].keys = np.array([[x,y] for x,y in zip(StateSpace['x'][StateSpace['Action']==action].values, StateSpace['y'][StateSpace['Action']==action].values)],dtype=np.float32)
    umap_agent.online_net.memories[action].values = np.array([[val] for val in StateSpace['Value'][StateSpace['Action']==action].values],dtype=np.float32)
  #Evaluation of the grid space
  for state in grid2eval:
    state = torch.as_tensor(np.squeeze(state.T)).to(device=args.device)
    with torch.no_grad():
      q_values = umap_agent.online_net(state.unsqueeze(0))[0]
      value, action = map(lambda x: x.item(),q_values.max(dim=1))
      grid_value, grid_action = np.append(grid_value,[value],axis=0), np.append(grid_action,[action],axis=0)
  #Plot of the projected States and the best Action in the grid according to a argmax policy
  
  kde_skl = KernelDensity(bandwidth=4,kernel='gaussian')
  kde_skl.fit(np.array([[x,y] for x,y in zip(StateSpace['x'].values, StateSpace['y'].values)],dtype=np.float32))
  kde_map = np.exp(kde_skl.score_samples(np.squeeze(grid2eval)))

  grid_2d = pd.DataFrame(data=np.concatenate((grid_x.reshape(x_len*y_len,1),grid_y.reshape(x_len*y_len,1),grid_action.reshape(len(grid_action),1),grid_value.reshape(len(grid_value),1),kde_map.reshape(len(kde_map),1)),axis=1),columns=['x','y','Action','Value','kde'])

  fig, axes = plt.subplots(1+agent.action_space, 4, figsize=(18,4*(1+agent.action_space)))
  plt.subplots_adjust(left=0.125, bottom=0.1, right=0.9, top=0.9, wspace=0.5, hspace=0.4)
  sns.scatterplot(StateSpace['x'],StateSpace['y'],hue=StateSpace['Value'],style = StateSpace['Action'],legend='brief',ax=axes[0][0])
  sns.heatmap(np.reshape(grid_2d['kde'].values,(x_len,y_len)),ax=axes[0][1])
  sns.scatterplot(grid_2d['x'][grid_2d['kde']>0.0008],grid_2d['y'][grid_2d['kde']>0.0008],hue=grid_2d['Action'],legend=False,ax=axes[0][2],s=(args.umap_step**2)*50)
  sns.scatterplot(grid_2d['x'][grid_2d['kde']>0.0008],grid_2d['y'][grid_2d['kde']>0.0008],hue=grid_2d['Value'],legend = 'brief',ax=axes[0][3],s=(args.umap_step**2)*50)
  fig.suptitle('Steps: '+str(T)+'   AVG Reward: '+str("{0:.2f}".format(avg_rew))+'   AVG Q: '+str("{0:.2f}".format(avg_Q)),fontsize=15)
  axes[0][0].set_ylim(ylim), axes[0][2].set_ylim(ylim), axes[0][3].set_ylim(ylim)
  axes[0][0].set_xlim(xlim), axes[0][2].set_xlim(xlim), axes[0][3].set_xlim(xlim)
  axes[0][0].legend(bbox_to_anchor=(0.9,1)), axes[0][3].legend(bbox_to_anchor=(0.9,1))
  axes[0][0].set_title('UMAP projection'), axes[0][1].set_title('Kernel Density Estimation'), axes[0][2].set_title('Action taken in Grid-Space'), axes[0][3].set_title('Q-values in Grid-Space')
  
  for action in range(agent.action_space):
    kde_skl = KernelDensity(bandwidth=4,kernel='gaussian')
    kde_skl.fit(np.array([[x,y] for x,y in zip(StateSpace['x'][StateSpace['Action']==action].values, StateSpace['y'][StateSpace['Action']==action].values)],dtype=np.float32))
    kde_map = np.exp(kde_skl.score_samples(np.squeeze(grid2eval)))
    grid_2d['kde'] = kde_map
    sns.scatterplot(StateSpace['x'][StateSpace['Action']==action].values,StateSpace['y'][StateSpace['Action']==action].values,hue=StateSpace['Value'][StateSpace['Action']==action],ax=axes[action+1][0],legend = 'brief')
    sns.heatmap(np.reshape(grid_2d['kde'].values,(x_len,y_len)),ax=axes[action+1][1])
    sns.scatterplot(grid_2d['x'][(grid_2d['kde']>0.0008) & (grid_2d['Action']==action)],grid_2d['y'][(grid_2d['kde']>0.0008) & (grid_2d['Action']==action)],ax=axes[action+1][2],s=(args.umap_step**2)*50)
    sns.scatterplot(grid_2d['x'][(grid_2d['kde']>0.0008) & (grid_2d['Action']==action)],grid_2d['y'][(grid_2d['kde']>0.0008) & (grid_2d['Action']==action)],hue=grid_2d['Value'][grid_2d['Action']==action],legend = 'brief',ax=axes[action+1][3],s=(args.umap_step**2)*50)
    fig.suptitle('Steps: '+str(T)+'   AVG Reward: '+str("{0:.2f}".format(avg_rew))+'   AVG Q: '+str("{0:.2f}".format(avg_Q)),fontsize=15)
    axes[action+1][0].set_ylim(ylim), axes[action+1][2].set_ylim(ylim), axes[action+1][3].set_ylim(ylim)
    axes[action+1][0].set_xlim(xlim), axes[action+1][2].set_xlim(xlim), axes[action+1][3].set_xlim(xlim)
    axes[action+1][0].legend(bbox_to_anchor=(0.9,1)), axes[action+1][3].legend(bbox_to_anchor=(0.9,1))
    axes[action+1][0].set_title('UMAP projection on action: '+str(action)), axes[action+1][1].set_title('KDE on action: '+str(action)), axes[action+1][2].set_title('Grid Space: '+str(action)), axes[action+1][3].set_title('Q-values on action: '+str(action))
  
  args.projection = projection
  plt.savefig(os.path.join(path_embeddings, 'Steps_'+str(T)+'_numK_'+str(len(values))+'.png'))
  plt.close()

def save_embedding(args, agent, results_dir):
  env_name = args.env if args.symbolic_env else args.game
  keys = np.empty((0,args.key_size),dtype=np.float32)
  for action in range(agent.action_space):
    indexes = [keys<1e6 for keys in (agent.online_net.memories[action].keys[:,0] if agent.online_net.memories[action].faiss_gpu_resources is None else agent.online_net.memories[action].keys[:,0].cpu().numpy())]
    keys = np.append(keys, agent.online_net.memories[action].keys[indexes] if agent.online_net.memories[action].faiss_gpu_resources is None else agent.online_net.memories[action].keys[indexes].cpu().numpy(),axis=0)
  embedding = umap.UMAP().fit(keys)
  path_embeddings = os.path.join(results_dir, 'embeddings_temp')
  os.makedirs(path_embeddings, exist_ok=True)
  torch.save(embedding, os.path.join(path_embeddings,env_name+'.pth'))






