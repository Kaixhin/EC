import numpy as np
import torch


class ExperienceReplay():
  def __init__(self, size, symbolic_env, observation_shape, device):
    self.device = device
    self.symbolic_env = symbolic_env
    self.size = size
    self.observations = np.empty((size, ) + observation_shape, dtype=np.float32 if symbolic_env else np.uint8)
    self.actions = np.empty((size, ), dtype=np.int64)
    self.returns = np.empty((size, ), dtype=np.float32) 
    self.idx, self.steps = 0, 0
    self.full = False  # Tracks if memory has been filled/all slots are valid

  def append_batch(self, observations, actions, returns):
    batch_size = returns.shape[0]
    idxs = np.linspace(self.idx, self.idx + batch_size - 1, batch_size, dtype=np.int64) % self.size
    if self.symbolic_env:
      self.observations[idxs] = observations
    else:
      self.observations[idxs] = np.array(observations * 255, dtype=np.uint8)  # Discretise visual observations (to save memory)
    self.actions[idxs] = actions
    self.returns[idxs] = returns
    self.idx = (self.idx + batch_size) % self.size
    self.steps += batch_size
    self.full = self.steps >= self.size

  # Returns a batch of transitions uniformly sampled from the memory
  def sample(self, n):
    idxs = np.random.randint(0, self.size if self.full else self.idx, size=n)
    if self.symbolic_env:
      observations = self.observations[idxs]
    else:
      observations = self.observations[idxs].astype(np.float32) / 255  # Un-discretise visual observations
    return torch.as_tensor(observations).to(device=self.device), torch.as_tensor(self.actions[idxs]).to(device=self.device), torch.as_tensor(self.returns[idxs]).to(device=self.device)

  # Set up internal state for iterator
  def __iter__(self):
    self.current_idx = 0
    return self

  # Return valid states for validation
  def __next__(self):
    if self.current_idx == self.size:
      raise StopIteration
    if self.symbolic_env:
      observation = self.observations[self.current_idx]
    else:
      observation = self.observations[self.current_idx].astype(np.float32) / 255  # Un-discretise visual observations
    self.current_idx += 1
    return torch.as_tensor(observation).to(device=self.device)
