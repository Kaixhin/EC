import os
from matplotlib import pyplot as plt


def plot(ys, xlabel, ylabel, title, path):
  plt.plot(range(len(ys)), ys)
  plt.xlabel(xlabel)
  plt.ylabel(ylabel)
  plt.savefig(os.path.join(path, title + '.png'))
  plt.close()
