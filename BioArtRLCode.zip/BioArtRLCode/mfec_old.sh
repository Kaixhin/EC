#!/bin/bash

GAMES=("pong" "bowling" "ms_pacman" "space_invaders" "qbert")
OMEGAS=(25 50 60 40 40)

for SEED in 123 456 789; do
  for POLICY in "egreedy" "mellowmax"; do
    for i in ${!GAMES[@]}; do
      python main.py --id "mfec_${POLICY}_${GAMES[$i]}_${SEED}" --seed $SEED --env atari --game ${GAMES[$i]} --T-max 5000000 --algorithm MFEC --policy $POLICY --key-size 128 --num-neighbours 11 --projection gaussian --dictionary-capacity 100000 --omega ${OMEGAS[$i]} --epsilon-final 0.005 --discount 0.99 --evaluation-interval 50000 
    done
  done
done
