import os
import torch

from envs import get_env
from utils import lineplot


# Globals
Ts, rewards, Qs, best_avg_reward = [], [], [], -1e10


# Test DQN
def test(args, T, agent, val_mem, results_dir, evaluate=False):
  global Ts, rewards, Qs, best_avg_reward
  env = get_env(args)
  env.seed(args.seed)
  env.eval()
  Ts.append(T)
  T_rewards, T_Qs = [], []

  # Test performance over several episodes
  done = True
  for _ in range(args.evaluation_episodes):
    while True:
      if done:
        state, reward_sum, done = env.reset(), 0, False

      action = agent.act(state)  # Choose an action ε-greedily (default for eval mode)
      state, reward, done = env.step(action)  # Step
      reward_sum += reward
      if args.render:
        env.render()

      if done:
        T_rewards.append(reward_sum)
        break
  env.close()

  # Test Q-values over validation memory
  for state in val_mem:  # Iterate over valid states
    T_Qs.append(agent.evaluate_q(state))

  avg_reward, avg_Q = sum(T_rewards) / len(T_rewards), sum(T_Qs) / len(T_Qs)
  if not evaluate:
    # Append to results
    rewards.append(T_rewards)
    Qs.append(T_Qs)

    # Plot
    lineplot(Ts, rewards, 'Reward', path=results_dir, xaxis='Step')
    lineplot(Ts, Qs, 'Q', path=results_dir, xaxis='Step')

    # Save model parameters if improved
    if avg_reward > best_avg_reward:
      best_avg_reward = avg_reward
      agent.save(results_dir)

  # Return rewards and Q-values
  return T_rewards, T_Qs
