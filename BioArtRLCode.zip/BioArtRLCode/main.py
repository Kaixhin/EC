import argparse
import atari_py
import os
import numpy as np
from tqdm import tqdm
import torch
from torch import optim

from agents import MFECAgent, NECAgent
from envs import get_env
from memory import ExperienceReplay
from test import test
from utils import log, plot_embedding, save_embedding


# Hyperparameters
parser = argparse.ArgumentParser(description='Episodic Control')
parser.add_argument('--id', type=str, default='default', help='Experiment ID')
parser.add_argument('--seed', type=int, default=123, help='Random seed')
parser.add_argument('--disable-cuda', action='store_true', help='Disable CUDA')
parser.add_argument('--env', type=str, default='cartpole', choices=['acrobot', 'cartpole', 'mountaincar', 'openroom', 'imaze', 'fourroom', 'atari'], help='Environment')
parser.add_argument('--game', type=str, default='pong', choices=atari_py.list_games(), help='ATARI game')
# parser.add_argument('--symbolic-env', action='store_true', help='Symbolic features')
parser.add_argument('--T-max', type=int, default=int(10e6), metavar='STEPS', help='Number of training steps (4x number of frames)')
parser.add_argument('--max-episode-length', type=int, default=int(108e3), metavar='LENGTH', help='Max episode length (0 to disable)')
parser.add_argument('--history-length', type=int, default=4, metavar='T', help='Number of consecutive states processed (ATARI)')  # 1 for MFEC (originally), 4 for MFEC (in NEC paper) and NEC
parser.add_argument('--algorithm', type=str, default='MFEC', choices=['MFEC', 'NEC'], help='Episodic control algorithm')
parser.add_argument('--policy', type=str, default='egreedy', choices=['egreedy', 'boltzmann', 'mellowmax', 'gumbel'], help='Policy')
parser.add_argument('--exploration', type=str, default='no', choices=['no', 'UCB', 'GP', 'Thompson'], help='Exploration Technique')
parser.add_argument('--key-size', type=int, default=64, metavar='SIZE', help='Key size')  # 64 for MFEC, 128 for NEC
parser.add_argument('--num-neighbours', type=int, default=11, metavar='p', help='Number of nearest neighbours')  # 11 for MFEC, 50 for NEC
parser.add_argument('--projection', type=str, default='none', choices=['none', 'gaussian', 'sparse'], help='MFEC random projection')
parser.add_argument('--model', type=str, metavar='PARAMS', help='Pretrained model (state dict)')
parser.add_argument('--memory-capacity', type=int, default=int(1e5), metavar='CAPACITY', help='Experience replay memory capacity')
parser.add_argument('--dictionary-capacity', type=int, default=int(1e6), metavar='CAPACITY', help='Dictionary capacity (per action)')  # 1e6 for MFEC, 5e5 for NEC
parser.add_argument('--replay-frequency', type=int, default=4, metavar='k', help='Frequency of sampling from memory')
parser.add_argument('--priority-exponent', type=float, default=0, metavar='ω', help='Prioritised experience replay exponent (originally denoted α)')
parser.add_argument('--priority-weight', type=float, default=1, metavar='β', help='Initial prioritised experience replay importance sampling weight')
parser.add_argument('--multi-step', type=int, default=1, metavar='n', help='Number of steps for multi-step return from experience replay')
parser.add_argument('--tau', type=float, default=1, help='Boltzmann/Gumbel temperature')
parser.add_argument('--gumbel-weight', type=float, default=1, help='Gumbel weight')
parser.add_argument('--omega', type=float, default=7.5, help='Omega in mellowmax operator')
parser.add_argument('--episodic-multi-step', type=int, default=1e6, metavar='n', help='Number of steps for multi-step return from end of episode')  # Infinity for MFEC, 100 for NEC
parser.add_argument('--epsilon-initial', type=float, default=1, metavar='ε', help='Initial value of ε-greedy policy')
parser.add_argument('--epsilon-final', type=float, default=0.005, metavar='ε', help='Final value of ε-greedy policy')  # 0.005 for MFEC, 0.001 for NEC
parser.add_argument('--epsilon-anneal-start', type=int, default=5000, metavar='ε', help='Number of steps before annealing ε')
parser.add_argument('--epsilon-anneal-end', type=int, default=25000, metavar='ε', help='Number of steps to finish annealing ε')
parser.add_argument('--discount', type=float, default=1, metavar='γ', help='Discount factor')  # 1 for MFEC, 0.99 for NEC
parser.add_argument('--reward-clip', type=int, default=0, metavar='VALUE', help='Reward clipping (0 to disable)')
parser.add_argument('--learning-rate', type=float, default=7.92468721e-6, metavar='η', help='Network learning rate')
parser.add_argument('--rmsprop-decay', type=float, default=0.95, metavar='α', help='RMSprop decay')
parser.add_argument('--rmsprop-epsilon', type=float, default=0.01, metavar='ε', help='RMSprop decay')
parser.add_argument('--dictionary-learning-rate', type=float, default=0.1, metavar='α', help='Dictionary learning rate')
parser.add_argument('--kernel', type=str, default='mean_IDW', choices=['mean', 'mean_IDW'], metavar='k', help='Kernel function')  # mean for MFEC, mean_IDF for NEC
parser.add_argument('--kernel-delta', type=float, default=1e-3, metavar='δ', help='Mean IDW kernel delta')
parser.add_argument('--batch-size', type=int, default=32, metavar='SIZE', help='Batch size')
parser.add_argument('--learn-start', type=int, default=0, metavar='STEPS', help='Number of steps before starting training')  # 0 for MFEC, 50000 for NEC
parser.add_argument('--evaluate', action='store_true', help='Evaluate only')
parser.add_argument('--evaluation-interval', type=int, default=100000, metavar='STEPS', help='Number of training steps between evaluations')
parser.add_argument('--evaluation-episodes', type=int, default=10, metavar='N', help='Number of evaluation episodes to average over')
parser.add_argument('--evaluation-size', type=int, default=500, metavar='N', help='Number of transitions to use for validating Q')
parser.add_argument('--evaluation-epsilon', type=float, default=0, metavar='ε', help='Value of ε-greedy policy for evaluation')
parser.add_argument('--checkpoint-interval', type=int, default=0, metavar='STEPS', help='Number of training steps between saving buffers (0 to disable)')  # TODO
parser.add_argument('--render', action='store_true', help='Display screen (testing only)')
parser.add_argument('--LTM', type=str, default='LRU', choices=['LRU', 'k_means','DKM', 'max_surprise', 'max_rewards'], help='Long Term Memory Technique')
parser.add_argument('--umap', action='store_true', help='UMAP visualisation of current embedding for every evaluation')
parser.add_argument('--umap-step', type=float, default=0.5, help='Step size of map of states to evaluate through UMAP')
parser.add_argument('--save-embedding', action='store_true', help='Save the UMAP embedding from the last evaluation')
args = parser.parse_args()
args.symbolic_env = args.env != 'atari'  # Manually set symbolic env
print(' ' * 26 + 'Options')
for k, v in vars(args).items():
  print(' ' * 26 + k + ': ' + str(v))

# Setup
results_dir = os.path.join('results', args.id)
os.makedirs(results_dir, exist_ok=True)
np.random.seed(args.seed)
torch.manual_seed(np.random.randint(1, 10000))
if torch.cuda.is_available() and not args.disable_cuda:
  args.device = torch.device('cuda')
  torch.cuda.manual_seed(np.random.randint(1, 10000))
else:
  args.device = torch.device('cpu')
metrics = {'train_steps': [], 'train_episodes': [], 'train_rewards': [], 'test_steps': [], 'test_rewards': [], 'test_Qs': []}


# Environment
env = get_env(args)
env.seed(args.seed)
env.train()
args.key_size = int(np.prod(env.observation_space.shape)) if args.projection == 'none' and args.algorithm == 'MFEC' else args.key_size


# Agent and memory
if args.algorithm == 'MFEC':
  agent = MFECAgent(args, env.observation_space.shape, env.action_space.n, env.hash_space.shape[0])
elif args.algorithm == 'NEC':
  agent = NECAgent(args, env.observation_space.shape, env.action_space.n, env.hash_space.shape[0])
  mem = ExperienceReplay(args.memory_capacity, args.symbolic_env, env.observation_space.shape, args.device)


# Construct validation memory
val_mem = ExperienceReplay(args.evaluation_size, args.symbolic_env, env.observation_space.shape, args.device)
T, done, states = 0, True, []  # Store transition data in episodic buffers
while T < args.evaluation_size:
  if done:
    state, done = env.reset(), False

  next_state, _, done = env.step(env.action_space.sample())
  # Append transition data to episodic buffers
  states.append(state.cpu().numpy())

  state = next_state
  T += 1
val_mem.append_batch(np.stack(states), np.zeros((args.evaluation_size, ), dtype=np.int64), np.zeros((args.evaluation_size, ), dtype=np.float32))


if args.evaluate:
  agent.eval()  # Set agent to evaluation mode
  test_rewards, test_Qs = test(args, 0, agent, val_mem, results_dir, evaluate=True)  # Test
  print('Avg. reward: ' + str(sum(test_rewards) / args.evaluation_episodes) + ' | Avg. Q: ' + str(sum(test_Qs) / args.evaluation_size))
else:
  # Training loop
  agent.train()
  T, done, epsilon = 0, True, args.epsilon_initial
  agent.set_epsilon(epsilon)
  for T in tqdm(range(1, args.T_max + 1)):
 
    if done:
      state, done = env.reset(), False
      states, actions, rewards, keys, values, hashes = [], [], [], [], [], []  # Store transition data in episodic buffers

    # Linearly anneal ε over set interval
    if T > args.epsilon_anneal_start and T <= args.epsilon_anneal_end:
      epsilon -= (args.epsilon_initial - args.epsilon_final) / (args.epsilon_anneal_end - args.epsilon_anneal_start)
      agent.set_epsilon(epsilon)
    
    # Append transition data to episodic buffers (1/2)
    states.append(state.cpu().numpy())
    hashes.append(env.get_state_hash())  # Use environment state hash function
    
    action, key, value = agent.act(state, return_key_value=True)  # Choose an action according to the policy
    next_state, reward, done = env.step(action)  # Step
    if args.reward_clip > 0:
      reward = max(min(reward, args.reward_clip), -args.reward_clip)  # Clip rewards
    # Append transition data to episodic buffers
    actions.append(action)
    rewards.append(reward)
    keys.append(key.cpu().numpy())  # Note that original NEC implementation does not recalculate keys at the end of the episode
    values.append(value)  # Note that original implementations do not recalculate values at the end of the episode

    # Calculate returns at episode to batch memory updates
    if done:
      episode_T = len(rewards)
      returns, multistep_returns = [None] * episode_T, [None] * episode_T
      returns.append(0)
      for i in range(episode_T - 1, -1, -1):  # Calculate return-to-go in reverse
        returns[i] = rewards[i] + args.discount * returns[i + 1]
        if episode_T - i > args.episodic_multi_step:  # Calculate multi-step returns (originally only for NEC)
          multistep_returns[i] = returns[i] + args.discount ** args.episodic_multi_step * (values[i + args.episodic_multi_step] - returns[i + args.episodic_multi_step])
        else:  # Calculate Monte Carlo returns (originally only for MFEC)
          multistep_returns[i] = returns[i]
      states, actions, returns, keys, hashes = np.stack(states), np.asarray(actions, dtype=np.int64), np.asarray(multistep_returns, dtype=np.float32), np.stack(keys), np.stack(hashes)
      unique_actions, unique_action_reverse_idxs = np.unique(actions, return_inverse=True)  # Find every unique action taken and indices
      for i, a in enumerate(unique_actions):
        a_idxs = (unique_action_reverse_idxs == i).nonzero()[0]
        if len(a_idxs)<=np.ceil(args.dictionary_capacity-1): # I can upload the memory in batch
          agent.update_memory_batch(a.item(), keys[a_idxs], returns[a_idxs][:, np.newaxis], hashes[a_idxs])  # Append transition to DND of action in batch
        else:
          while len(a_idxs)>0:
            agent.update_memory_batch(a.item(), keys[a_idxs[:np.int64(np.ceil(args.dictionary_capacity-1))]], returns[a_idxs[:np.int64(np.ceil(args.dictionary_capacity-1))]][:, np.newaxis], hashes[a_idxs[:np.int64(np.ceil(args.dictionary_capacity-1))]])  # Append transition to DND of action in batch
            a_idxs = a_idxs[np.int64(np.ceil(args.dictionary_capacity-1)):]
      if args.algorithm == 'NEC':
        mem.append_batch(states, actions, returns)  # Append transition to memory in batch

      # Save metrics
      metrics['train_steps'].append(T)
      metrics['train_episodes'].append(len(metrics['train_episodes']) + 1)
      metrics['train_rewards'].append(sum(rewards))
      torch.save(metrics, os.path.join(results_dir, 'metrics.pth'))

    # Train and test
    if T >= args.learn_start:
      if args.algorithm == 'NEC' and T % args.replay_frequency == 0:
        agent.learn(mem)  # Train network
      if T % args.evaluation_interval == 0: #its time to evaluate
        agent.eval()  # Set agent to evaluation mode
        test_rewards, test_Qs = test(args, T, agent, val_mem, results_dir)  # Test
        log('T = ' + str(T) + ' / ' + str(args.T_max) + ' | Avg. reward: ' + str(sum(test_rewards) / args.evaluation_episodes) + ' | Avg. Q: ' + str(sum(test_Qs) / args.evaluation_size))
        if args.umap: plot_embedding(args, MFECAgent if args.algorithm=='MFEC' else NECAgent, agent, env, T, results_dir, sum(test_rewards) / args.evaluation_episodes, sum(test_Qs) / args.evaluation_size)
        if args.save_embedding and (T+args.evaluation_interval) > args.T_max: save_embedding(args, agent, results_dir)
        agent.train()  # Set agent back to training mode
        metrics['test_steps'].append(T)
        metrics['test_rewards'].append(test_rewards)
        metrics['test_Qs'].append(test_Qs)
        torch.save(metrics, os.path.join(results_dir, 'metrics.pth'))
    state = next_state

env.close()
