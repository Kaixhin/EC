import os
from matplotlib import pyplot as plt
import seaborn as sns
import torch


results = torch.zeros(2, 5, 3, 100, 3)  # Algorithms x Games x Methods x Evaluations x Seeds
ALGOS = {'MFEC': 0, 'NEC': 1}
GAMES = {'bowling': 0, 'ms': 1, 'pong': 2, 'qbert': 3, 'space': 4}
METHODS = {'D3QN': 0, "$\epsilon$-greedy": 1, 'Mellowmax': 2}
COLOURS = ['#000000', '#69b13e', '#cd116c']
SEEDS = {'123': 0, '456': 1, '789': 2}


for exp in os.listdir('results'):
  if '123' in exp or '456' in exp or '789' in exp:
    metrics = torch.load(os.path.join('results', exp, 'metrics.pth'))
    ind_0 = 0 if ('d3qn' in exp or 'mfec' in exp) else 1
    try:
      ind_1 = GAMES[exp.split('_')[1]]  # D3QN
    except KeyError:
      ind_1 = GAMES[exp.split('_')[2]]  # MFEC/NEC
    ind_2 = 1 if 'egreedy' in exp else 2
    ind_2 = 0 if 'd3qn' in exp else ind_2
    ind_3 = SEEDS[exp.split('_')[-1]]
    results[ind_0, ind_1, ind_2, :, ind_3] = torch.tensor(metrics['test_rewards'], dtype=torch.float32).mean(dim=1)  # Average over 10 evaluations
    if 'd3qn' in exp:  # Include D3QN results as baseline for both algorithms
      results[1, ind_1, ind_2, :, ind_3] = torch.tensor(metrics['test_rewards'], dtype=torch.float32).mean(dim=1)  # Average over 10 evaluations


sns.set()
fig = plt.figure()

x_axis = torch.linspace(0, 5, 100).numpy()
for algo_k, algo_v in ALGOS.items():
  for game_k, game_v in GAMES.items():
    for met_k, met_v in METHODS.items():
      y_mean, y_std = results[algo_v, game_v, met_v].mean(dim=-1).numpy(), results[algo_v, game_v, met_v].std(dim=-1).numpy()
      ax = sns.lineplot(x=x_axis, y=y_mean, color=COLOURS[met_v])
      ax.fill_between(x_axis, y1=y_mean - y_std, y2=y_mean + y_std, color=COLOURS[met_v], alpha=0.2, linewidth=0)  # Standard deviations
    ax.set_ylabel('Reward')
    ax.set_xlabel("Steps $\\times 10^6$")
    ax.autoscale(enable=True, axis='x', tight=True)
    ax.legend(METHODS.keys(), loc='upper left')
    plt.tight_layout()
    fig.savefig(os.path.join('results', algo_k + '_' + game_k + '.png'))
    fig.clear()
