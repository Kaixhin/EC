from abc import ABC, abstractmethod
import os
import numpy as np
import torch
from torch.nn import functional as F 
from models import MFEC, NEC
from optimisers import RMSprop
from scipy import optimize
from scipy.special import logsumexp, softmax


# Implementation from https://github.com/chainer/chainerrl/blob/master/chainerrl/functions/mellowmax.py
def _mellowmax(x, omega):
  return (logsumexp(omega * x) - np.log(len(x))) / omega


# TODO: Batch version?
def _maxent_mellowmax(x, omega, beta_min=-100, beta_max=100):
  mm = _mellowmax(x, omega)
  adv = x - mm
  if np.allclose(adv, np.zeros_like(adv), atol=1e-3):  # Root solving is unstable when all values are close to 0
    beta = 0
  else:
    beta = optimize.brentq(lambda y, adv: np.sum(np.exp(y * adv) * adv), a=beta_min, b=beta_max, args=(adv, ))
  return softmax(beta * np.asarray(x, dtype='float64'))


class _EpisodicAgent(ABC):
  def __init__(self, args):
    self.policy = args.policy
    self.tau = 1  # Boltzmann/Gumbel temperature
    self.gumbel_weight = 1  # Gumbel weight
    self.omega = args.omega  # Mellowmax temperature
    self.exploration = args.exploration
    self.train_epsilon = 0
    self.eval_epsilon = args.evaluation_epsilon
    self.training = True

  # Acts based on single state (no batch)
  def act(self, state, return_key_value=False):
    with torch.no_grad():
      q_values, key = self.online_net(state.unsqueeze(dim=0))
      value, action = map(lambda x: x.item(), q_values.max(dim=1))  # Value of argmax policy used for evaluation
      # TODO: If exploration is not none (UCB/GP/Thompson), then act greedily; incompatible with boltzmann/mellowmax?
      if self.exploration == 'no':
        if self.policy == 'egreedy' or not self.training:  # Always use ε-greedy policy for evaluation
          epsilon = self.train_epsilon if self.training else self.eval_epsilon
          action = np.random.randint(0, self.action_space) if np.random.random() < epsilon else action
        elif self.policy == 'boltzmann':
          action = torch.multinomial(F.softmax(q_values / self.tau, dim=1), 1).item()
        elif self.policy == 'mellowmax':
          policy = _maxent_mellowmax(q_values[0].cpu().numpy(), self.omega, beta_min=-100, beta_max=100)
          action = np.nonzero(np.random.multinomial(1, policy))[0][0]
        elif self.policy == 'gumbel':
          gumbel_noise = torch.empty_like(q_values).uniform_().add_(1e-9).log_().mul_(-1).add_(1e-9).log_().mul_(-1)
          policy = F.softmax((q_values + self.gumbel_weight * gumbel_noise) / self.tau, dim=1)
          action = policy.argmax(dim=1).item()
      if return_key_value:
        return action, key.squeeze(dim=0), value
      else:
        return action

  def update_memory_batch(self, action, keys, rewards, hashes):
    self.online_net.memories[action].update_batch(keys, rewards, hashes)

  # Save model parameters on current device (don't move model between devices)
  def save(self, path):
    torch.save(self.online_net.state_dict(), os.path.join(path, 'model.pth'))

  # Evaluates Q-value based on a single state (no batch)
  def evaluate_q(self, state):
    with torch.no_grad():
      return self.online_net(state.unsqueeze(0))[0].max().item()

  def train(self):
    self.training = True
    self.online_net.train()

  def eval(self):
    self.training = False
    self.online_net.eval()

  # Sets training ε for ε-greedy policy
  def set_epsilon(self, epsilon):
    self.train_epsilon = epsilon


class MFECAgent(_EpisodicAgent):
  def __init__(self, args, observation_shape, action_space, hash_size):
    super().__init__(args)
    self.action_space = action_space
    self.online_net = MFEC(args, observation_shape, action_space, hash_size, args.projection).to(device=args.device)
    if args.model and os.path.isfile(args.model):
      self.online_net.load_state_dict(torch.load(args.model, map_location='cpu'))  # Always load tensors onto CPU by default, will shift to GPU if necessary
    self.online_net.train()


class NECAgent(_EpisodicAgent):
  def __init__(self, args, observation_shape, action_space, hash_size):
    super().__init__(args)
    self.action_space = action_space
    self.batch_size = args.batch_size

    self.online_net = NEC(args, observation_shape, action_space, hash_size).to(device=args.device)
    if args.model and os.path.isfile(args.model):
      self.online_net.load_state_dict(torch.load(args.model, map_location='cpu'))  # Always load tensors onto CPU by default, will shift to GPU if necessary
    self.online_net.train()

    self.optimiser = RMSprop(self.online_net.parameters(), lr=args.learning_rate, alpha=args.rmsprop_decay, eps=args.rmsprop_epsilon)

  def learn(self, mem):
    # Sample transitions
    states, actions, returns = mem.sample(self.batch_size)
    # Calculate Q-values
    q_values, neighbours, values, idxs, _ = self.online_net(states, learning=True)
    q_values = q_values[range(self.batch_size), actions]
    # Minimise residual between Q-values and multi-step returns
    loss = F.mse_loss(q_values, returns)
    self.optimiser.zero_grad()
    # Calculate gradients and update network parameters
    loss.backward()
    self.optimiser.step()
    # Update keys and values with gradients
    for n, v, i, m in zip(neighbours, values, idxs, self.online_net.memories):
      m.gradient_update(n, v, i)
