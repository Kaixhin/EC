#!/bin/bash


declare -a LTM=("LRU" "DKM")

declare -a game=("pong" "bowling" "ms_pacman" "space_invaders" "qbert")


for i in 123 456 789; do
	for ind_ltm in 1 2 ; do
		for ind_game in 1 2 3 4 5 ; do
			python main.py --id "NEC-10k-${LTM[$ind_ltm-1]}-${game[$ind_game-1]}-${i}" --algorithm NEC --key-size 128 --learn-start 50000 --num-neighbours 50 --epsilon-final 0.001 --episodic-multi-step 100 --seed $i --LTM ${LTM[$ind_ltm-1]} --evaluation-interval 50000 --T-max 10000000 --dictionary-capacity 10000 --discount 0.99 --env atari --game ${game[$ind_game-1]} 
		done
	done
done

