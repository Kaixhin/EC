import faiss
import numpy as np
import torch
from utils import knn_search


def set_dictionary_coefficient(dictionary_capacity, LTM):
	if LTM=='LRU':
		return np.linspace(dictionary_capacity, 1, dictionary_capacity, dtype=np.int32)
	elif LTM=='DKM':
		return np.zeros(dictionary_capacity, dtype=np.float32)
	elif LTM=='k_means':
		return np.zeros(dictionary_capacity, dtype=np.int32)
	elif LTM=='max_surprise':
		return np.zeros(dictionary_capacity, dtype=np.float32)
	elif LTM=='max_rewards':
		return np.ones(dictionary_capacity, dtype=np.float32) * -1e6


def LRU(self, keys, values, hashes):
	# Test for matching states in batch
	sorted_idxs = np.argsort(values, axis=0)[::-1][:, 0]  # Sort values in descending order (max value first); equivalent to purely online update
	keys, values, hashes = keys[sorted_idxs], values[sorted_idxs], hashes[sorted_idxs]  # Rearrange keys, values and hashes in this order
	hashes, unique_indices = np.unique(hashes, axis=0, return_index=True)  # Retrieve unique hashes and indices of first occurences in array
	keys, values = keys[unique_indices], values[unique_indices]  # Extract corresponding keys and values

	# Perform hash check for exact matches
	dists, idxs = knn_search(hashes, self.hashes, 1)  # TODO: Replace kNN search with real hash check
	dists, idxs = dists[:, 0], idxs[:, 0]
	match_idxs, non_match_idxs = np.nonzero(dists == 0)[0], np.nonzero(dists)[0]
	num_matches, num_non_matches = len(match_idxs), len(non_match_idxs)
	# Update last access (updated for all lookups: acting, return calculation and training)
	self.dictionary_coefficient += 1  # Increment last access for all items

	# Update exact match with best return (risk seeking)
	if num_matches > 0:
		idxs_match_idxs = idxs[match_idxs]
		if hasattr(self, "rmsprop_keys_square_avg"):
			self.values[idxs_match_idxs] += self.alpha * (values[match_idxs] - self.values[idxs_match_idxs])
		else:
			self.values[idxs_match_idxs] = np.maximum(self.values[idxs_match_idxs], values[match_idxs])
		self.dictionary_coefficient[idxs_match_idxs] = 0

	# Otherwise add new states and Monte Carlo returns, replacing least recently updated entries
	if num_non_matches > 0:
		lru_idxs = np.argpartition(self.dictionary_coefficient, -num_non_matches)[-num_non_matches:]  # Find top-k LRU items
		self.keys[lru_idxs] = keys[non_match_idxs] if self.faiss_gpu_resources is None else torch.from_numpy(keys[non_match_idxs]).to(device=self.keys.device)
		self.values[lru_idxs] =  values[non_match_idxs]
		self.hashes[lru_idxs] = hashes[non_match_idxs]
		self.dictionary_coefficient[lru_idxs] = 0
		if hasattr(self, "rmsprop_keys_square_avg"): self.rmsprop_keys_square_avg[lru_idxs], self.rmsprop_values_square_avg[lru_idxs] = 0, 0

def k_means(self, keys, values, hashes):
	dists, idxs = knn_search(hashes, self.hashes, 1)  
	dists, idxs = dists[:, 0], idxs[:, 0]
	count_zero = (self.dictionary_coefficient == 0).sum()
	if count_zero>0:
		if len(idxs)<=count_zero:
			ltm_idxs = np.argpartition(self.dictionary_coefficient, len(idxs))[:len(idxs)]  
			self.keys[ltm_idxs] = keys if self.faiss_gpu_resources is None else torch.from_numpy(keys).to(device=self.keys.device)
			self.values[ltm_idxs] =  values
			self.hashes[ltm_idxs] = hashes
			self.dictionary_coefficient[ltm_idxs] = 1
			if hasattr(self, "rmsprop_keys_square_avg"): self.rmsprop_keys_square_avg[ltm_idxs], self.rmsprop_values_square_avg[ltm_idxs] = 0, 0
		else:
			ltm_idxs = np.argpartition(self.dictionary_coefficient, count_zero)[:count_zero]  
			self.keys[ltm_idxs] = keys[:len(ltm_idxs)] if self.faiss_gpu_resources is None else torch.from_numpy(keys[:len(ltm_idxs)]).to(device=self.keys.device)
			self.values[ltm_idxs] =  values[:len(ltm_idxs)]
			self.hashes[ltm_idxs] = hashes[:len(ltm_idxs)]
			self.dictionary_coefficient[ltm_idxs] = 1
			if hasattr(self, "rmsprop_keys_square_avg"): self.rmsprop_keys_square_avg[ltm_idxs], self.rmsprop_values_square_avg[ltm_idxs] = 0, 0
			keys, values, hashes, idxs = keys[len(ltm_idxs):], values[len(ltm_idxs):], hashes[len(ltm_idxs):], idxs[len(ltm_idxs):]
			unique_idxs, unique_idxs_reverse_idxs = np.unique(idxs, return_inverse=True)  # Find every unique hash and indices
			if (len(unique_idxs)<len(idxs)):
				agg_keys, agg_values, agg_hashes, agg_plus_size = [], [], [], []  # Aggregate keys, values and hashes (in case of duplicates)
				for i, h in enumerate(unique_idxs):
					h_idxs = (unique_idxs_reverse_idxs == i).nonzero()[0]
					agg_keys.append(np.mean(keys[h_idxs], axis=0, keepdims=True))  # Average keys
					agg_values.append(np.mean(values[h_idxs], axis=0, keepdims=True))  # Average values
					agg_hashes.append(np.mean(hashes[h_idxs], axis=0, keepdims=True))  # Average keys
					agg_plus_size.append(len(h_idxs))
				keys, values, hashes, idxs, plus_size = np.concatenate(agg_keys), np.concatenate(agg_values), np.concatenate(agg_hashes), unique_idxs, np.asarray(agg_plus_size)
			else: plus_size=np.ones(len(idxs),dtype=np.int32)
			self.keys[idxs] = np.divide(np.sum([np.multiply(self.keys[idxs], self.dictionary_coefficient[idxs][:,np.newaxis]), keys], axis=0), (self.dictionary_coefficient[idxs] + 1)[:,np.newaxis], dtype=np.float32) if self.faiss_gpu_resources is None else torch.from_numpy(np.divide(np.sum([np.multiply(self.keys[idxs].cpu().numpy(), self.dictionary_coefficient[idxs][:,np.newaxis]), keys], axis=0), (self.dictionary_coefficient[idxs] + 1)[:,np.newaxis], dtype=np.float32)).to(device=self.keys.device)
			self.values[idxs] =  np.divide(np.sum([np.multiply(self.values[idxs], self.dictionary_coefficient[idxs][:,np.newaxis]), values], axis=0), (self.dictionary_coefficient[idxs] + 1)[:,np.newaxis])
			self.hashes[idxs] =  np.divide(np.sum([np.multiply(self.hashes[idxs], self.dictionary_coefficient[idxs][:,np.newaxis]), hashes], axis=0), (self.dictionary_coefficient[idxs] + 1)[:,np.newaxis])
			self.dictionary_coefficient[idxs] += plus_size
	else:
		unique_idxs, unique_idxs_reverse_idxs = np.unique(idxs, return_inverse=True)  # Find every unique hash and indices
		if (len(unique_idxs)<len(idxs)):
			agg_keys, agg_values, agg_hashes, agg_plus_size = [], [], [], []  # Aggregate keys, values and hashes (in case of duplicates)
			for i, h in enumerate(unique_idxs):
				h_idxs = (unique_idxs_reverse_idxs == i).nonzero()[0]
				agg_keys.append(np.mean(keys[h_idxs], axis=0, keepdims=True))  # Average keys
				agg_values.append(np.mean(values[h_idxs], axis=0, keepdims=True))  # Average values
				agg_hashes.append(np.mean(hashes[h_idxs], axis=0, keepdims=True))  # Average keys
				agg_plus_size.append(len(h_idxs))
			keys, values, hashes, idxs, plus_size = np.concatenate(agg_keys), np.concatenate(agg_values), np.concatenate(agg_hashes), unique_idxs, np.asarray(agg_plus_size)
		else: plus_size=np.ones(len(idxs),dtype=np.int32)
		self.keys[idxs] = np.divide(np.sum([np.multiply(self.keys[idxs], self.dictionary_coefficient[idxs][:,np.newaxis]), keys], axis=0), (self.dictionary_coefficient[idxs] + 1)[:,np.newaxis], dtype=np.float32) if self.faiss_gpu_resources is None else torch.from_numpy(np.divide(np.sum([np.multiply(self.keys[idxs].cpu().numpy(), self.dictionary_coefficient[idxs][:,np.newaxis]), keys], axis=0), (self.dictionary_coefficient[idxs] + 1)[:,np.newaxis], dtype=np.float32)).to(device=self.keys.device)
		self.values[idxs] =  np.divide(np.sum([np.multiply(self.values[idxs], self.dictionary_coefficient[idxs][:,np.newaxis]), values], axis=0), (self.dictionary_coefficient[idxs] + 1)[:,np.newaxis])
		self.hashes[idxs] =  np.divide(np.sum([np.multiply(self.hashes[idxs], self.dictionary_coefficient[idxs][:,np.newaxis]), hashes], axis=0), (self.dictionary_coefficient[idxs] + 1)[:,np.newaxis])
		self.dictionary_coefficient[idxs] += plus_size


def DKM(self, keys, values, hashes):
	clusters_annealing = len(values)/len(self.dictionary_coefficient)
	dists, idxs = knn_search(hashes, self.hashes, 1)  # TODO: Replace kNN search with real hash check
	dists, idxs = dists[:, 0], idxs[:, 0]
	count_zero = (self.dictionary_coefficient <= 0).sum()
	if count_zero>0:
		if len(idxs)<=count_zero:
			ltm_idxs = np.argpartition(self.dictionary_coefficient, len(idxs)-1)[:len(idxs)]  
			self.keys[ltm_idxs] = keys if self.faiss_gpu_resources is None else torch.from_numpy(keys).to(device=self.keys.device)
			self.values[ltm_idxs] =  values
			self.hashes[ltm_idxs] = hashes
			self.dictionary_coefficient[ltm_idxs] = 1
			if hasattr(self, "rmsprop_keys_square_avg"): self.rmsprop_keys_square_avg[ltm_idxs], self.rmsprop_values_square_avg[ltm_idxs] = 0, 0
		else:
			ltm_idxs = np.argpartition(self.dictionary_coefficient, count_zero)[:count_zero]  
			self.keys[ltm_idxs] = keys[:len(ltm_idxs)] if self.faiss_gpu_resources is None else torch.from_numpy(keys[:len(ltm_idxs)]).to(device=self.keys.device)
			self.values[ltm_idxs] =  values[:len(ltm_idxs)]
			self.hashes[ltm_idxs] = hashes[:len(ltm_idxs)]
			self.dictionary_coefficient[ltm_idxs] = 1
			if hasattr(self, "rmsprop_keys_square_avg"): self.rmsprop_keys_square_avg[ltm_idxs], self.rmsprop_values_square_avg[ltm_idxs] = 0, 0
			keys, values, hashes, idxs = keys[len(ltm_idxs):], values[len(ltm_idxs):], hashes[len(ltm_idxs):], idxs[len(ltm_idxs):]
			unique_idxs, unique_idxs_reverse_idxs = np.unique(idxs, return_inverse=True)  # Find every unique hash and indices
			if (len(unique_idxs)<len(idxs)):
				agg_keys, agg_values, agg_hashes, agg_plus_size = [], [], [], []  # Aggregate keys, values and hashes (in case of duplicates)
				for i, h in enumerate(unique_idxs):
					h_idxs = (unique_idxs_reverse_idxs == i).nonzero()[0]
					agg_keys.append(np.mean(keys[h_idxs], axis=0, keepdims=True))  # Average keys
					agg_values.append(np.mean(values[h_idxs], axis=0, keepdims=True))  # Average values
					agg_hashes.append(np.mean(hashes[h_idxs], axis=0, keepdims=True))  # Average keys
					agg_plus_size.append(len(h_idxs))
				keys, values, hashes, idxs, plus_size = np.concatenate(agg_keys), np.concatenate(agg_values), np.concatenate(agg_hashes), unique_idxs, np.asarray(agg_plus_size)
			else: plus_size=np.ones(len(idxs),dtype=np.float32)
			temp_dict = [dict_ for dict_ in self.dictionary_coefficient]
			self.dictionary_coefficient[self.dictionary_coefficient < 0] = 0
			self.keys[idxs] = np.divide(np.sum([np.multiply(self.keys[idxs], self.dictionary_coefficient[idxs][:,np.newaxis]), keys], axis=0), (self.dictionary_coefficient[idxs] + 1)[:,np.newaxis], dtype=np.float32) if self.faiss_gpu_resources is None else torch.from_numpy(np.divide(np.sum([np.multiply(self.keys[idxs].cpu().numpy(), self.dictionary_coefficient[idxs][:,np.newaxis]), keys], axis=0), (self.dictionary_coefficient[idxs] + 1)[:,np.newaxis], dtype=np.float32)).to(device=self.keys.device)
			self.values[idxs] =  np.divide(np.sum([np.multiply(self.values[idxs], self.dictionary_coefficient[idxs][:,np.newaxis]), values], axis=0), (self.dictionary_coefficient[idxs] + 1)[:,np.newaxis])
			self.hashes[idxs] =  np.divide(np.sum([np.multiply(self.hashes[idxs], self.dictionary_coefficient[idxs][:,np.newaxis]), hashes], axis=0), (self.dictionary_coefficient[idxs] + 1)[:,np.newaxis])
			self.dictionary_coefficient = np.asarray([dict_ for dict_ in temp_dict], dtype=np.float32)
			self.dictionary_coefficient[idxs] += plus_size
			self.dictionary_coefficient -= clusters_annealing
	else:
		unique_idxs, unique_idxs_reverse_idxs = np.unique(idxs, return_inverse=True)  # Find every unique hash and indices
		if (len(unique_idxs)<len(idxs)):
			agg_keys, agg_values, agg_hashes, agg_plus_size = [], [], [], []  # Aggregate keys, values and hashes (in case of duplicates)
			for i, h in enumerate(unique_idxs):
				h_idxs = (unique_idxs_reverse_idxs == i).nonzero()[0]
				agg_keys.append(np.mean(keys[h_idxs], axis=0, keepdims=True))  # Average keys
				agg_values.append(np.mean(values[h_idxs], axis=0, keepdims=True))  # Average values
				agg_hashes.append(np.mean(hashes[h_idxs], axis=0, keepdims=True))  # Average keys
				agg_plus_size.append(len(h_idxs))
			keys, values, hashes, idxs, plus_size = np.concatenate(agg_keys), np.concatenate(agg_values), np.concatenate(agg_hashes), unique_idxs, np.asarray(agg_plus_size)
		else: plus_size=np.ones(len(idxs),dtype=np.float32)
		self.keys[idxs] = np.divide(np.sum([np.multiply(self.keys[idxs], self.dictionary_coefficient[idxs][:,np.newaxis]), keys], axis=0), (self.dictionary_coefficient[idxs] + 1)[:,np.newaxis], dtype=np.float32) if self.faiss_gpu_resources is None else torch.from_numpy(np.divide(np.sum([np.multiply(self.keys[idxs].cpu().numpy(), self.dictionary_coefficient[idxs][:,np.newaxis]), keys], axis=0), (self.dictionary_coefficient[idxs] + 1)[:,np.newaxis], dtype=np.float32)).to(device=self.keys.device)
		self.values[idxs] =  np.divide(np.sum([np.multiply(self.values[idxs], self.dictionary_coefficient[idxs][:,np.newaxis]), values], axis=0), (self.dictionary_coefficient[idxs] + 1)[:,np.newaxis])
		self.hashes[idxs] =  np.divide(np.sum([np.multiply(self.hashes[idxs], self.dictionary_coefficient[idxs][:,np.newaxis]), hashes], axis=0), (self.dictionary_coefficient[idxs] + 1)[:,np.newaxis])
		self.dictionary_coefficient[idxs] += plus_size
		self.dictionary_coefficient -= clusters_annealing


def max_surprise(self, keys, values, hashes):
	dists, idxs = knn_search(keys, self.keys if self.faiss_gpu_resources is None else self.keys.cpu().numpy(), self.num_neighbours)  # TODO: Replace kNN search with real hash check
	weights = self.kernel(dists, self.kernel_opts)  # Apply kernel function
	weights = np.divide(weights, np.sum(weights, axis=1).reshape(len(keys),1))  # Normalise weights
	values_from_neigh = self.values[idxs].reshape((idxs.shape[0], self.num_neighbours, 1)) # Retrieve values
	output = np.sum((np.multiply(weights,np.squeeze(values_from_neigh))), axis=1)
	surprise = abs(np.squeeze(values)-output)
	sorted_idxs = np.argsort(surprise, axis=0)[::-1] # Sort values in descending order (max value first) TODO: Is this the way it should be done?
	keys, values, hashes, surprise = keys[sorted_idxs], values[sorted_idxs], hashes[sorted_idxs], surprise[sorted_idxs]  # Rearrange keys, values and hashes in this order
	keys, unique_indices = np.unique(keys, axis=0, return_index=True)  # Retrieve unique hashes and indices of first occurences in array
	hashes, values, surprise = hashes[unique_indices], values[unique_indices], surprise[unique_indices]  # Extract corresponding keys and values

	ltm_idxs = np.argpartition(self.dictionary_coefficient, len(surprise))[:len(surprise)]  
	self.keys[ltm_idxs] = keys if self.faiss_gpu_resources is None else torch.from_numpy(keys).to(device=self.keys.device)
	self.values[ltm_idxs] =  values
	self.hashes[ltm_idxs] = hashes
	self.dictionary_coefficient[ltm_idxs] = surprise
	if hasattr(self, "rmsprop_keys_square_avg"): self.rmsprop_keys_square_avg[ltm_idxs], self.rmsprop_values_square_avg[ltm_idxs] = 0, 0

def max_rewards(self, keys, values, hashes):
	# Test for matching states in batch
	sorted_idxs = np.argsort(values, axis=0)[::-1][:, 0]  # Sort values in descending order (max value first); equivalent to purely online update
	keys, values, hashes = keys[sorted_idxs], values[sorted_idxs], hashes[sorted_idxs]  # Rearrange keys, values and hashes in this order
	hashes, unique_indices = np.unique(hashes, axis=0, return_index=True)  # Retrieve unique hashes and indices of first occurences in array
	keys, values = keys[unique_indices], values[unique_indices]  # Extract corresponding keys and values

	ltm_idxs = np.argpartition(self.dictionary_coefficient, len(values))[:len(values)]  
	self.keys[ltm_idxs] = keys if self.faiss_gpu_resources is None else torch.from_numpy(keys).to(device=self.keys.device)
	self.values[ltm_idxs] =  values
	self.hashes[ltm_idxs] = hashes
	self.dictionary_coefficient[ltm_idxs] = np.squeeze(values)
	if hasattr(self, "rmsprop_keys_square_avg"): self.rmsprop_keys_square_avg[ltm_idxs], self.rmsprop_values_square_avg[ltm_idxs] = 0, 0










