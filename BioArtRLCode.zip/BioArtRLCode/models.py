from math import sqrt
import faiss
import GPy
import numpy as np
from scipy.sparse import csr_matrix
import scipy.stats as stats
from sklearn import random_projection
import torch
from torch import nn
from torch.nn import functional as F
from kernels import InverseDistance
from utils import knn_search
from long_term_memory import set_dictionary_coefficient, LRU, k_means, DKM, max_surprise, max_rewards


# Set up GPU scratch space for FAISS
def _setup_faiss_gpu_resources(device):
  if device == torch.device('cuda'):
    res = faiss.StandardGpuResources()
    res.setDefaultNullStreamAllDevices()
    # res.setTempMemory(64 * 1024 * 1024)  # Do not decrease memory allocation for resource object (large amount needed for example for Atari)
    return res
  else:
    return None


# Mean kernel
def _mean_kernel(squared_l2_dists, opts=None):
    return torch.ones_like(squared_l2_dists)


# Kernel that interpolates between the mean for short distances and weighted inverse distance for large distances
def _mean_IDW_kernel(squared_l2_dists, opts):
    return 1 / (squared_l2_dists + opts['delta'])


# Dictionary-based memory (assumes key-value associations do not change)
class StaticDictionary(nn.Module):
  def __init__(self, args, hash_size, faiss_gpu_resources=None):
    super().__init__()
    self.exploration = args.exploration
    self.key_size = args.key_size
    self.faiss_gpu_resources = faiss_gpu_resources
    self.num_neighbours = args.num_neighbours
    if args.kernel == 'mean':
      self.kernel = _mean_kernel
    elif args.kernel == 'mean_IDW':
      self.kernel = _mean_IDW_kernel
    self.kernel_opts = {'delta': args.kernel_delta}
    
    self.keys = 1e6 * np.ones((args.dictionary_capacity, args.key_size), dtype=np.float32)  # Add initial keys with very large magnitude values (infinity results in kNN returning -1 as indices)
    if self.faiss_gpu_resources is not None:
      self.keys = torch.from_numpy(self.keys).to(device=args.device)
    self.values = np.zeros((args.dictionary_capacity, 1), dtype=np.float32)
    self.hashes = 1e6 * np.ones((args.dictionary_capacity, hash_size), dtype=np.float32)  # Assumes hash of 1e6 will never appear TODO: Replace with an actual dictionary?
    self.dictionary_coefficient = set_dictionary_coefficient(args.dictionary_capacity, args.LTM) #set memory coefficient to manage dictionary updates
    self.LTM = args.LTM
    self.seed = args.seed

  # Lookup function TODO: Can we keep these all on GPU?
  def forward(self, key):
    # Perform kNN search TODO: Do we do hash check here or assume kNN is fine since key-value associations don't change?
    output = torch.zeros(key.size(0), 1, device=key.device)
    dists, idxs, neighbours = knn_search(key.detach().cpu().numpy() if self.faiss_gpu_resources is None else key.detach(), self.keys, self.num_neighbours, return_neighbours=True, res=self.faiss_gpu_resources)  # Return (squared) L2 distances and indices of nearest neighbours
    dists, idxs = (dists, idxs) if self.faiss_gpu_resources is None else (dists.cpu().numpy(), idxs.cpu().numpy())
    match_idxs, non_match_idxs = np.nonzero(dists[:, 0] == 0)[0], np.nonzero(dists[:, 0])[0]  # Detect exact matches (based on first returned distance) and non-matches
    
    # Use stored return for exact match
    output[match_idxs] = torch.from_numpy(self.values[idxs[match_idxs, 0]]).to(device=key.device)
    
    # For non-matches, use (possibly weighted) average return over k nearest neighbours
    idxs_non_match_idxs = idxs[non_match_idxs]
    values = self.values[idxs_non_match_idxs.reshape(-1)].reshape((idxs_non_match_idxs.shape[0], self.num_neighbours, 1))  # Retrieve values
    if self.exploration == 'UCB' or self.exploration == 'GP' or self.exploration == 'Thompson':
      # TODO: Batch version
      X, y = neighbours[non_match_idxs][0], values[0]
      # print(stats.normaltest(y))
      # print(stats.skewtest(y))
      X_mean, y_mean = np.mean(X, axis=0, keepdims=True), np.mean(y, axis=0, keepdims=True)
      X_test = key.detach().cpu().numpy() - X_mean
      kernel = InverseDistance(self.key_size, delta=1e-3)  # GPy.kern.RBF(obs_size, variance=1.,lengthscale=1.)
      m = GPy.models.GPRegression(X - X_mean, y - y_mean, kernel)
      if self.exploration == 'GP':
        m.optimize(max_f_eval=1000)
      y_mean1, y_var1 = m.predict(X_test)
      y_mean1 += y_mean
      y_std_dev1 = y_var1 ** .5
      if self.exploration == 'Thompson':
        _output = np.random.normal(y_mean1, y_std_dev1)
      else:  
        _output = y_mean1 + (y_std_dev1)
      output[non_match_idxs] = torch.from_numpy(_output).to(dtype=torch.float32, device=key.device)
    else:
      weights = self.kernel(torch.from_numpy(dists[non_match_idxs]).to(device=key.device), self.kernel_opts)  # Apply kernel function
      weights /= weights.sum(dim=1, keepdim=True)  # Normalise weights
      output[non_match_idxs] = torch.sum(weights.unsqueeze(dim=2) * torch.from_numpy(values).to(device=key.device), dim=1)

    # Update dictionary coefficient if LRU
    if self.LTM=='LRU':
      self.dictionary_coefficient += 1  # Increment last access for all items
      self.dictionary_coefficient[idxs.reshape(-1)] = 0  
    return output

  # Updates a batch of key-value pairs
  def update_batch(self, keys, values, hashes):
    eval(self.LTM+'(self, keys, values, hashes)')

class MFEC(nn.Module):
  def __init__(self, args, observation_shape, action_space, hash_size, projection):
    super().__init__()
    if projection == 'gaussian':
      self.register_buffer('projection', torch.tensor(random_projection.GaussianRandomProjection(n_components=args.key_size)._make_random_matrix(args.key_size, np.prod(observation_shape)), dtype=torch.float32).t())  # TODO: Check if DeepMind corrected variance for key size
    elif projection == 'sparse':
      self.register_buffer('projection', torch.tensor(csr_matrix.todense(random_projection.SparseRandomProjection(n_components=args.key_size, dense_output=True)._make_random_matrix(args.key_size, np.prod(observation_shape))), dtype=torch.float32).t())  # TODO: Check if DeepMind corrected variance for key size
    faiss_gpu_resources = _setup_faiss_gpu_resources(args.device)
    self.memories = [StaticDictionary(args, hash_size, faiss_gpu_resources) for _ in range(action_space)]

  def forward(self, observation):
    keys = observation.view(observation.size(0), -1)
    keys = torch.matmul(keys, self.projection) if hasattr(self, 'projection') else keys
    q_values = torch.cat([memory(keys) for memory in self.memories], dim=1)
    return q_values, keys


# Differentiable neural dictionary
class DND(StaticDictionary):
  def __init__(self, args, hash_size, faiss_gpu_resources=None):
    super().__init__(args, hash_size, faiss_gpu_resources=faiss_gpu_resources)
    self.key_size = args.key_size
    self.alpha = args.dictionary_learning_rate
    # RMSprop components
    self.rmsprop_learning_rate, self.rmsprop_decay, self.rmsprop_epsilon = args.learning_rate, args.rmsprop_decay, args.rmsprop_epsilon
    self.rmsprop_keys_square_avg, self.rmsprop_values_square_avg = torch.zeros(args.dictionary_capacity, args.key_size), torch.zeros(args.dictionary_capacity, 1)

  # Lookup function TODO: Can we keep these all on GPU?
  def forward(self, key, learning=False):
    # Perform kNN search
    if learning:
      _, idxs, neighbours = knn_search(key.detach().cpu().numpy() if self.faiss_gpu_resources is None else key.detach(), self.keys, self.num_neighbours, return_neighbours=True, res=self.faiss_gpu_resources)  # Retrieve actual neighbours
      neighbours = torch.tensor(neighbours, requires_grad=True).to(device=key.device) if self.faiss_gpu_resources is None else neighbours.requires_grad_(True)
      dists = (key.unsqueeze(dim=1) - neighbours).pow(2).sum(dim=2)  # Recalculate (squared) L2 distance for differentiation
      # TODO: Check if exact match causes gradient problems
    else:
      dists, idxs = knn_search(key.detach().cpu().numpy() if self.faiss_gpu_resources is None else key.detach(), self.keys, self.num_neighbours, res=self.faiss_gpu_resources)
      dists = torch.tensor(dists).to(device=key.device) if self.faiss_gpu_resources is None else dists
    idxs = idxs if self.faiss_gpu_resources is None else idxs.cpu()

    # Use weighted average return over k nearest neighbours
    weights = self.kernel(dists, self.kernel_opts)  # Apply kernel function
    weights /= weights.sum(dim=1, keepdim=True)  # Normalise weights
    values = self.values[idxs.reshape(-1)].reshape((idxs.shape[0], self.num_neighbours, 1))  # Retrieve values
    values = torch.tensor(values, requires_grad=True).to(device=key.device)
    output = torch.sum(weights.unsqueeze(dim=2) * values, dim=1)

    # Update dictionary coefficient if LRU
    if self.LTM=='LRU':
      self.dictionary_coefficient += 1  # Increment last access for all items
      self.dictionary_coefficient[idxs.reshape(-1)] = 0   
    if learning:
      return output, neighbours, values, idxs
    else:
      return output

  # Updates a batch of key-value pairs
  def update_batch(self, keys, values, hashes):
    eval(self.LTM+'(self, keys, values, hashes)')

  # Performs a sparse RMSprop update
  def gradient_update(self, keys, values, idxs):
    idxs, unique_idxs = np.unique(idxs.reshape(-1), return_index=True)  # Check for duplicates to remove
    keys, values = keys.reshape(-1, self.key_size)[unique_idxs], values.reshape(-1, 1)[unique_idxs]  # Remove duplicate keys and values
    if keys.grad is not None:
      grad = keys.grad.data
      square_avg = self.rmsprop_keys_square_avg[idxs]
      square_avg.mul_(self.rmsprop_decay).addcmul_(1 - self.rmsprop_decay, grad, grad)
      avg = square_avg.add(self.rmsprop_epsilon).sqrt_()
      keys.data.addcdiv_(-self.rmsprop_learning_rate, grad, avg)
      self.keys[idxs] = keys.detach().cpu().numpy()
      self.rmsprop_keys_square_avg[idxs] = square_avg
    if values.grad is not None:
      grad = values.grad.data
      square_avg = self.rmsprop_values_square_avg[idxs]
      square_avg.mul_(self.rmsprop_decay).addcmul_(1 - self.rmsprop_decay, grad, grad)
      avg = square_avg.add(self.rmsprop_epsilon).sqrt_()
      values.data.addcdiv_(-self.rmsprop_learning_rate, grad, avg)
      self.values[idxs] = values.detach().cpu().numpy()
      self.rmsprop_values_square_avg[idxs] = square_avg


class NEC(nn.Module):
  def __init__(self, args, observation_shape, action_space, hash_size):
    super().__init__()
    self.symbolic_env = args.symbolic_env
    if self.symbolic_env:
      self.fc1 = nn.Linear(np.prod(observation_shape), args.key_size)
      self.fc_keys = nn.Linear(args.key_size, args.key_size)
    else:
      self.conv1 = nn.Conv2d(args.history_length, 32, 8, stride=4, padding=1)
      self.conv2 = nn.Conv2d(32, 64, 4, stride=2)
      self.conv3 = nn.Conv2d(64, 64, 3)
      self.fc_keys = nn.Linear(3136, args.key_size)
    faiss_gpu_resources = _setup_faiss_gpu_resources(args.device)
    self.memories = [DND(args, hash_size, faiss_gpu_resources) for _ in range(action_space)]

  def forward(self, observation, learning=False):
    if self.symbolic_env:
      hidden = F.relu(self.fc1(observation.view(observation.size(0), -1)))
      keys = self.fc_keys(hidden)
    else:
      hidden = F.relu(self.conv1(observation))
      hidden = F.relu(self.conv2(hidden))
      hidden = F.relu(self.conv3(hidden))
      keys = self.fc_keys(hidden.view(-1, 3136))
    memory_output = [memory(keys, learning) for memory in self.memories]
    if learning:
      memory_output, neighbours, values, idxs = zip(*memory_output)
      return torch.cat(memory_output, dim=1), neighbours, values, idxs, keys  # Return Q-values, neighbours, values and keys
    else:
      return torch.cat(memory_output, dim=1), keys  # Return Q-values and keys
